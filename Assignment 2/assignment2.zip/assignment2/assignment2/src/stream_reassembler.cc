#include "stream_reassembler.hh"
#include <algorithm>

StreamReassembler::StreamReassembler(const size_t capacity)
    : _output(capacity), _unassembled(), _first_unassembled_byte(0), _capacity(capacity), _eof(false) {}

void StreamReassembler::push_substring(const std::string &data, const uint64_t index, const bool eof) {

    size_t space_left = _capacity - (_output.bytes_written() - _output.bytes_read());
    size_t i = index;
    size_t written = 0;
    bool flag = 0;
    
    for (char c : data) {
        if (i >= _capacity) flag = 1;
        if (i >= _first_unassembled_byte && written < space_left) {
            _unassembled[i] = c;
            i++;
            written++;
        } else if (written >= space_left) {
            break;
        } else {
            i++;
        }
    }
    //std::cout << eof << " " << _eof << " " << flag << " " << data.length() << " " << space_left <<std::endl;
    if (eof && !flag) _eof = true;
    
    auto it = _unassembled.begin();
    while (it != _unassembled.end() && it->first == _first_unassembled_byte) {
        _first_unassembled_byte += _output.write(std::string(1, it->second));
        it = _unassembled.erase(it);
        //_first_unassembled_byte++;
    }
    //std::cout << _first_unassembled_byte << std::endl;
    if (_eof && _unassembled.empty()) {
        _output.end_input();
    }
}

size_t StreamReassembler::unassembled_bytes() const {
    return _unassembled.size();
}

bool StreamReassembler::empty() const {
    return _unassembled.empty();
}

size_t StreamReassembler::ack_index() const {
    return _first_unassembled_byte;
}
