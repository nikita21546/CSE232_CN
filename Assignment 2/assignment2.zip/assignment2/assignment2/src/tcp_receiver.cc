#include "tcp_receiver.hh"
#include <algorithm>

void TCPReceiver::segment_received(const TCPSegment &seg) {
    const TCPHeader head = seg.header();
    uint64_t checkpoint = _reassembler.ack_index();
    uint64_t abs_seqno = unwrap(head.seqno, _isn, checkpoint);
    uint64_t stream_idx = abs_seqno - _synReceived;
    //std::cout <<"stream_idx = " << stream_idx << std::endl;
    if (!head.syn && !_synReceived) return;
    if (!_synReceived){
        _synReceived = true;
        _isn = head.seqno;
    }
    if (_synReceived){
        std::string data = std::string(seg.payload());
        _reassembler.push_substring(data, stream_idx, _finReceived);
    }
    if (head.fin){
        _finReceived = true;
        if (_reassembler.unassembled_bytes() == 0)
            _reassembler.stream_out().end_input();
    } 
}

std::optional<WrappingInt32> TCPReceiver::ackno() const {
    if (_synReceived) {
        uint64_t index = _reassembler.ack_index() + 1 + _finReceived;
        //std::cout << "fin = " << index << _reassembler.ack_index() << std::endl;
        return (wrap(index, _isn));
    }
    return {};
}

size_t TCPReceiver::window_size() const {
    if (_finReceived) {
        return 0;
    } else {
        return _capacity - _reassembler.stream_out().buffer_size();
    }
}
