#ifndef SPONGE_LIBSPONGE_STREAM_REASSEMBLER_HH
#define SPONGE_LIBSPONGE_STREAM_REASSEMBLER_HH

#include "byte_stream.hh"
#include "wrapping_integers.hh"
#include <algorithm>
#include <cstdint>
#include <deque>
#include <iostream>
#include <string>
#include <map> 


class StreamReassembler {
  private:
    size_t _first_unassembled_byte;
    size_t _capacity;
    bool _eof;
    std::map<size_t, char> _unassembled;
    ByteStream _output;

  public:
    StreamReassembler(const size_t capacity);
    void push_substring(const std::string &data, const size_t index, const bool eof);
    const ByteStream &stream_out() const { return _output; }
    ByteStream &stream_out() { return _output; }
    size_t unassembled_bytes() const;
    bool empty() const;
    size_t ack_index() const;    
};

#endif  // SPONGE_LIBSPONGE_STREAM_REASSEMBLER_HH
