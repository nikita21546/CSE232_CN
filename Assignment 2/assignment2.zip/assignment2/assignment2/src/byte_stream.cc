#include "byte_stream.hh"
#include <algorithm>

using namespace std;

ByteStream::ByteStream(const size_t capa) : capacity(capa), inputEnded(false), errorFlag(false), bytesWritten(0), bytesRead(0) {}

size_t ByteStream::write(const std::string &data) {
  if (inputEnded and !errorFlag) {
    return 0;
  }
  size_t remaining = capacity - buffer.size();
  size_t bytes_write = std::min(remaining, data.length());
  for (size_t i = 0; i < bytes_write; ++i) {
    buffer.push_back(data[i]);
  }
  bytesWritten += bytes_write;
  return bytes_write;
}

string ByteStream::peek_output(const size_t len) const {
  size_t bufferSize = buffer.size();
  size_t bytes_peek = min(len, bufferSize);
  string result(buffer.begin(), buffer.begin() + bytes_peek);
  return result;
}

void ByteStream::pop_output(const size_t len) {
  size_t bufferSize = buffer.size();
  if (len > bufferSize){
    set_error();
    return;
  }
  size_t bytes_pop = std::min(len, bufferSize);
  for (size_t i = 0; i < bytes_pop; ++i) {
    buffer.pop_front();
  }
  bytesRead += bytes_pop;
}

std::string ByteStream::read(const size_t len) {
  size_t bufferSize = buffer.size();
  if (len > bufferSize){
    set_error();
    return "";
  }
  size_t bytes_read = std::min(len, bufferSize);
  std::string result(buffer.begin(), buffer.begin() + bytes_read);
  for (size_t i = 0; i < bytes_read; ++i) {
    buffer.pop_front();
  }
  bytesRead += bytes_read;
  return result;
}

void ByteStream::end_input() {
  inputEnded = true;
}

bool ByteStream::input_ended() const {
  return inputEnded;
}

size_t ByteStream::buffer_size() const {
  return buffer.size();
}

bool ByteStream::buffer_empty() const {
  return buffer.empty();
}

bool ByteStream::eof() const {
  return inputEnded && buffer.empty();
}

size_t ByteStream::bytes_written() const {
  return bytesWritten;
}

size_t ByteStream::bytes_read() const {
  return bytesRead;
}

size_t ByteStream::remaining_capacity() const {
  return capacity - buffer.size();
}
