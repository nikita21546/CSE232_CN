#include "wrapping_integers.hh"
#include <iostream>

static const auto wrap_around = 1ULL << 32;
using namespace std;

WrappingInt32 wrap(uint64_t n, WrappingInt32 isn) {
    return isn + (n % wrap_around);
}

uint64_t unwrap(WrappingInt32 n, WrappingInt32 isn, uint64_t checkpoint) {
    uint64_t diff = n.raw_value() - isn.raw_value();
    uint64_t locateRound = (checkpoint/wrap_around);
    uint64_t val = locateRound*wrap_around + diff;

    uint64_t right,left;
    if (val < checkpoint) {
        val += wrap_around;
    }
    right = val - checkpoint;
    left = checkpoint - val + wrap_around;
    if (val >= wrap_around) {
        if (right > left) {
            return val - wrap_around;
        }
    }
    return static_cast<uint64_t>(val);
}
