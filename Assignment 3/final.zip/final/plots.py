from scapy.all import rdpcap
import numpy as np
import matplotlib.pyplot as plt

def compute_metrics(pcap_file, time_interval=10):
    packets = rdpcap(pcap_file)
    
    flow_info = {}
    current_time = None
    
    for packet in packets:
        if 'TCP' not in packet:
            continue

        src_ip = packet['IP'].src
        src_port = packet['TCP'].sport
        dst_ip = packet['IP'].dst
        dst_port = packet['TCP'].dport
        flow_key = (src_ip, src_port, dst_ip, dst_port)

        if flow_key not in flow_info:
            flow_info[flow_key] = {
                'timestamps': [],
                'packet_sizes': [],
            }

        flow_info[flow_key]['timestamps'].append(packet.time)
        flow_info[flow_key]['packet_sizes'].append(len(packet))

        if current_time is None:
            current_time = packet.time

        if packet.time - current_time >= time_interval:
            throughput, latency = calculate_metrics(flow_info)
            current_time = packet.time
            yield throughput, latency

def calculate_metrics(flow_info):
    throughput = {}
    latency = {}

    for flow_key, info in flow_info.items():
        timestamps = info['timestamps']
        packet_sizes = info['packet_sizes']
        time_diff = [timestamps[i] - timestamps[i - 1] for i in range(1, len(timestamps))]
        time_diff = [float(td) for td in time_diff]
        if not time_diff:
            continue 

        throughput[flow_key] = sum(packet_sizes) * 8 / sum(time_diff)
        latency[flow_key] = np.mean(time_diff) * 1000

    return throughput, latency

def plot_throughput(throughput, filename, start, end):
    plt.figure(figsize=(10, 5))
    keys = list(throughput.keys())
    values = list(throughput.values())
    keys = keys[start:end]
    values = values[start:end]
    plt.plot(range(len(keys)), values)
    plt.xticks(range(len(keys)), keys, rotation=45)
    plt.title('Throughput for TCP Flows')
    plt.xlabel('Flow')
    plt.ylabel('Throughput (bps)')
    plt.savefig(f"{filename}_throughput.png")
    plt.show()

def plot_latency(latency, filename, start, end):
    plt.figure(figsize=(10, 5))
    keys = list(latency.keys())
    values = list(latency.values())
    keys = keys[start:end]
    values = values[start:end]
    plt.plot(range(len(keys)), values, 'ro')
    plt.xticks(range(len(keys)), keys, rotation=45)
    plt.title('Latency for TCP Flows')
    plt.xlabel('Flow')
    plt.ylabel('Latency (ms)')
    plt.savefig(f"{filename}_latency.png")
    plt.show()

if __name__ == "__main__":
    pcap_file = 'epoll_3000.pcap' 
    time_interval = 10  
    for throughput, latency in compute_metrics(pcap_file, time_interval):
        start_interval = 0
        end_interval = 60
        plot_throughput(throughput, "epoll_3000_th", start_interval, end_interval)
        plot_latency(latency, "epoll_3000_l", start_interval, end_interval)


